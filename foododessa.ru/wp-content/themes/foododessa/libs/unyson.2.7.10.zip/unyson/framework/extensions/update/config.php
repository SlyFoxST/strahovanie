<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

/**
 * Do not show details about each extension update, but show it as one update
 * (simplify users life)
 */
$cfg['extensions_as_one_update'] = true;
